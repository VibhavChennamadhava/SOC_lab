# Topic 3 — Rootcheck Trojan Detection (PoC)

## Objective

Demonstrate Wazuh **Rootcheck** detecting suspicious binary tampering by simulating a "trojanized" system utility in a controlled lab environment, and validating alerts in Wazuh Dashboard.

---

## SOC Context (Why it matters)

Trojanized binaries and modified system utilities are common persistence techniques. Rootcheck helps detect:

- Unexpected changes to critical system files
- Known trojan patterns and rootkit indicators
- Host integrity drift that should trigger triage

---

## Lab Setup

- **Manager VM (Ubuntu):** Wazuh Indexer + Manager + Dashboard
- **Agent VM (Ubuntu):** Wazuh Agent with Rootcheck enabled

---

## Configuration Verification (Agent VM)

### Confirm Rootcheck is enabled

File: `/var/ossec/etc/ossec.conf`

```xml
<rootcheck>
  <disabled>no</disabled>
  <check_files>yes</check_files>
  <check_trojans>yes</check_trojans>
  <frequency>43200</frequency>
</rootcheck>
```

Verify configuration:

```bash
sudo grep -A 5 "<rootcheck>" /var/ossec/etc/ossec.conf
```

**Screenshot:** Rootcheck configuration

![Rootcheck Config](./screenshots/poc-2-rootcheck/rootcheck_config.png)

---

## Attack Simulation (Safe PoC)

### Step 1 — Backup a system binary

We'll use `/usr/bin/w` as the target (safe and reversible).

```bash
sudo cp -a /usr/bin/w /usr/bin/w.copy
ls -l /usr/bin/w /usr/bin/w.copy
```

### Step 2 — Replace the original with a wrapper script

```bash
sudo tee /usr/bin/w > /dev/null <<'EOF'
#!/bin/bash
echo "$(date) this is evil" > /tmp/trojan_created_file
echo "test for /usr/bin/w trojaned file" >> /tmp/trojan_created_file
# Run original binary
/usr/bin/w.copy "$@"
EOF

sudo chmod +x /usr/bin/w
```

### Step 3 — Verify wrapper runs

```bash
/usr/bin/w | head
cat /tmp/trojan_created_file
```

> **Important:** If you see "No such file or directory", confirm the wrapper calls `/usr/bin/w.copy` (not `/user/bin/w.copy`).

**Screenshots:** Creating trojan and verification

![Creating Trojan](./screenshots/poc-2-rootcheck/creating_trojan.png)

![Trojan Artifact](./screenshots/poc-2-rootcheck/trojan_artifact.png)

---

## Trigger Detection

Rootcheck runs on a schedule, so force it by restarting the agent:

```bash
sudo systemctl restart wazuh-agent
```

Verify rootcheck scan ran:

```bash
sudo tail -n 200 /var/ossec/logs/ossec.log | grep -i rootcheck
```

---

## Wazuh Alert Analysis (Dashboard)

Go to **Threat Hunting** and search:

**Option A (broad search):**

```
location:rootcheck
```

**Option B (specific rule ID):**

```
location:rootcheck AND rule.id:510
```

Open the event details and capture the full message (proof of detection).

**Screenshots:** Detection in dashboard

![Rootcheck Detection](./screenshots/poc-2-rootcheck/detected.png)

![Event Details](./screenshots/poc-2-rootcheck/detected_event_details.png)

---

## Cleanup (Restore Original Binary)

**Important:** Don't skip this step to restore your system to normal state.

```bash
sudo mv -f /usr/bin/w.copy /usr/bin/w
sudo rm -f /tmp/trojan_created_file
sudo systemctl restart wazuh-agent
```

Verify restoration:

```bash
ls -l /usr/bin/w
test -f /tmp/trojan_created_file && echo "Cleanup failed" || echo "Cleanup successful"
```

---

## Expected Outcome

- Rootcheck generates an alert indicating suspicious modification/trojan detection
- The event is visible in Wazuh Dashboard under Threat Hunting (Rootcheck location)
- Alert displays detection of trojanized `/usr/bin/w` binary

---

## Notes / Troubleshooting

### Common Issues

**Issue: `/usr/bin/w` errors with "No such file or directory"**

- **Cause:** Wrapper script has incorrect path
- **Fix:** Confirm the wrapper calls:
  - ✅ `/usr/bin/w.copy` (correct)
  - ❌ `/user/bin/w.copy` (typo - missing 's')

**Issue: No Rootcheck alerts appear**

- Verify Rootcheck is enabled: `<disabled>no</disabled>`
- Allow time for scan completion (or restart agent to force scan)
- Check agent logs: `sudo tail -n 200 /var/ossec/logs/ossec.log | grep -i rootcheck`

---

## Screenshot Mapping

- Rootcheck configuration → `./screenshots/poc-2-rootcheck/rootcheck_config.png`
- Creating trojan wrapper → `./screenshots/poc-2-rootcheck/creating_trojan.png`
- Trojan artifact verification → `./screenshots/poc-2-rootcheck/trojan_artifact.png`
- Detection in dashboard → `./screenshots/poc-2-rootcheck/detected.png`
- Event details panel → `./screenshots/poc-2-rootcheck/detected_event_details.png`

---

## References

- [Wazuh Rootcheck Documentation](https://documentation.wazuh.com/current/user-manual/capabilities/malware-detection/anomaly-and-malware-detection.html)
- [Wazuh PoC Guide - Rootcheck](https://documentation.wazuh.com/current/proof-of-concept-guide/index.html)

---

## Key Takeaways

- Validated Wazuh Rootcheck's ability to detect binary tampering
- Simulated a realistic trojanized binary in a safe, reversible manner
- Confirmed alert generation and visualization in Wazuh Dashboard
- Practiced proper cleanup procedures to restore system integrity
