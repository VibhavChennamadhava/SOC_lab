# Topic 2: File Integrity Monitoring (FIM) — PoC (Ubuntu Agent)

## Objective

Validate Wazuh File Integrity Monitoring (FIM) by detecting **file creation, modification, and deletion** events from a monitored directory on the Ubuntu Agent VM and visualizing alerts in the Wazuh Dashboard.

---

## Why this matters (SOC context)

FIM is a core SOC signal for:

- Unauthorized changes to sensitive files (configs, binaries, scripts)
- Persistence behaviors (droppers modifying startup files)
- Integrity drift in regulated environments (audit/compliance)

Wazuh generates alerts when monitored files are **added, modified, or deleted**.

---

## Configuration Steps (Agent VM)

> **Edit the Wazuh agent configuration file:**  
> Linux path: `/var/ossec/etc/ossec.conf`

### Step 1 — Create a dedicated lab directory (recommended)

Instead of monitoring all of `/home` (noisy), monitor a controlled lab folder:

```bash
sudo mkdir -p /home/<USER>/SOC_lab
sudo chown -R <USER>:<USER> /home/<USER>/SOC_lab
```

> **Note:** For realtime monitoring, the directory must exist **before** restarting the agent.

### Step 2 — Configure FIM (syscheck)

Open the config:

```bash
sudo nano /var/ossec/etc/ossec.conf
```

Inside the `<syscheck>` block, add:

```xml
<directories check_all="yes" report_changes="yes" realtime="yes">/home/<USER>/SOC_lab</directories>
```

This matches Wazuh's PoC structure (monitor a directory, enable realtime + report_changes).

**What each option does (quick SOC explanation):**

- `realtime="yes"`: continuous monitoring of directories (works on directories, not single files).
- `check_all="yes"`: records the full set of file attributes (hashes, perms, etc.).
- `report_changes="yes"`: includes file content diffs (limited to text files).

✅ **Important:** The attribute name is `report_changes` (not `report_changer`). If misspelled, Wazuh may ignore it.

**Screenshot:** syscheck configuration

![FIM syscheck directories config](./screenshots/topic-2-fim/directories_config.png)

---

### Step 3 — Restart the agent to apply changes

```bash
sudo systemctl restart wazuh-agent
```

This is required after modifying `ossec.conf`.

**Optional verification (agent-side logs):**

```bash
sudo tail -n 200 /var/ossec/logs/ossec.log | grep -i syscheck
```

---

## Attack Simulation (PoC Test)

Wazuh's PoC validation is simple:

1. Create a file
2. Modify it
3. Delete it

Run these on the **Agent VM**:

```bash
# 1) Create
echo "v1" > /home/<USER>/SOC_lab/test.txt
sleep 5

# 2) Modify
echo "v2" >> /home/<USER>/SOC_lab/test.txt
sleep 5

# 3) Delete
rm -f /home/<USER>/SOC_lab/test.txt
```

**Screenshot:** terminal file changes

![FIM test terminal](./screenshots/topic-2-fim/fim_test_terminal.png)

> **Path verification:** If you previously ran commands like `/vibe/SOC_lab/test.txt`, double-check the path.  
> In your terminal screenshot, your working directory is `/home/vibhav-ubuntu`, so the correct absolute path would be:  
> `/home/vibhav-ubuntu/vibe/SOC_lab/test.txt`

---

## Wazuh Alert Analysis (Dashboard)

Go to:  
**Wazuh Dashboard → File Integrity Monitoring → Events**

Apply filters for default FIM rule IDs:

- **554** = file added
- **550** = file modified (checksum changed)
- **553** = file deleted

**Filter example:**

- `rule.id: is one of 550,553,554`

Then optionally narrow:

- `agent.name: "<YOUR_AGENT_NAME>"`
- `syscheck.path: "/home/<USER>/SOC_lab/test.txt"`

**Screenshot:** FIM Events in dashboard

![FIM events](./screenshots/topic-2-fim/fim_events.png)

---

## Expected Output

You should see 3 events:

| Action | Expected rule.id | syscheck.event |
|--------|------------------|----------------|
| Create file | 554 | added |
| Modify file | 550 | modified |
| Delete file | 553 | deleted |

These correspond to Wazuh's default FIM rules for add/modify/delete.

---

## Notes / Noise Control (Enterprise-style tuning)

If you monitor broad paths like `/home/`, expect many events from desktop/system activity.

In real SOC environments, you tune by:

- Monitoring only high-value directories (configs, app folders)
- Using `<ignore>` rules for noisy paths
- Building custom FIM rules (e.g., alert only on `.ssh/authorized_keys`, `/etc/sudoers`, etc.)

---

## Screenshot Mapping

- `directories code.png` → `./screenshots/topic-2-fim/directories_config.png`
- `filecheck_1.png` → `./screenshots/topic-2-fim/fim_test_terminal.png`
- `filecheck_2.png` → `./screenshots/topic-2-fim/fim_events.png`

---

## References

- [Wazuh PoC - File Integrity Monitoring](https://documentation.wazuh.com/current/proof-of-concept-guide/poc-file-integrity-monitoring.html)
- [FIM Basic Settings](https://documentation.wazuh.com/current/user-manual/capabilities/file-integrity/basic-settings.html)
- [Syscheck Configuration Reference](https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html)
- [Creating Custom FIM Rules](https://documentation.wazuh.com/current/user-manual/capabilities/file-integrity/creating-custom-fim-rules.html)

---

## Next Steps

If you want to provide your actual `<syscheck>` block from `/var/ossec/etc/ossec.conf`, I can help:

- Clean it up (remove duplicates / fix typos)
- Reduce noise (avoid monitoring all `/home`)
- Make the PoC alerts show exactly for your `SOC_lab/test.txt`
