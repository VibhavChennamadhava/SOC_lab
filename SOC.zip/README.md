# Wazuh SOC Home Lab — Manager + Agent Deployment (Ubuntu on VirtualBox)

> **About**  
> This repository documents my SOC-style home lab where I deployed **Wazuh** for real-time endpoint monitoring, log visibility, and validation of agent-to-manager telemetry in a controlled environment.  
> The lab runs entirely on **two Ubuntu VMs** inside **Oracle VirtualBox**:
> - **Manager VM:** Wazuh Indexer + Wazuh Manager + Wazuh Dashboard  
> - **Agent VM:** Wazuh Agent (Ubuntu endpoint)
>
> This document covers **Topic 1: Installation Setup (Manager + Agent)** and focuses on operational verification + common troubleshooting patterns (connectivity, enrollment, agent identity, and service health).

---

## Architecture

### High-level Flow

```mermaid
flowchart LR
  M[Manager VM<br/>Ubuntu<br/>Wazuh Indexer + Manager + Dashboard]
  A[Agent VM<br/>Ubuntu<br/>Wazuh Agent]

  A -->|1515/TCP Enrollment agent-auth| M
  A -->|1514/TCP Events logs/alerts| M
  M -->|HTTPS Dashboard 443 or 5601| A

  subgraph Oracle VirtualBox Host Network
    M
    A
  end
```

### Architecture Diagram

![Architecture Diagram Placeholder](./docs/images/architecture_diagram.png)

---

## Prerequisites

### Hardware (Minimum Recommended)

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| Host RAM | 16 GB | 32 GB |
| Host CPU | 4 cores | 8+ cores |
| Disk | 60 GB free | 120 GB+ free |

### Software

- Oracle VirtualBox
- Ubuntu 22.04 / 24.04 (Manager VM + Agent VM)
- Wazuh Stack (Indexer + Manager + Dashboard) on Manager VM
- Wazuh Agent package on Agent VM

### Networking Requirements

Both VMs must share a reachable network path (Host-only or Bridged strongly recommended).

**Required ports:**

- **1514/TCP** — Agent event channel (remoted)
- **1515/TCP** — Agent enrollment/authd (agent-auth)
- **443 or 5601/TCP** — Wazuh Dashboard (varies by deployment)

---

## Topic 1: Installation Setup

### Objective

Deploy a functional Wazuh environment with:

1. A working **Wazuh Manager VM** (Indexer + Manager + Dashboard)
2. A connected **Agent VM** reporting to the manager
3. Verified ingestion and visibility of endpoint events in **Threat Hunting**

---

## Lab Components

| VM | Role | Purpose |
|----|------|---------|
| **Manager VM** | Wazuh Indexer + Manager + Dashboard | Central SIEM/XDR, alerting, hunting |
| **Agent VM** | Wazuh Agent (Ubuntu) | Endpoint telemetry collection & security monitoring |

---

## Network Setup

**Design principle:** avoid NAT-only addresses for manager/agent communication.

✅ **Recommended:** Host-only or Bridged network between the two Ubuntu VMs  
❌ **Common pitfall:** agent enrolls to a NAT IP that is not reachable from the agent VM

**Quick connectivity checks (Agent VM → Manager VM):**

```bash
nc -vz <MANAGER_IP> 1514
nc -vz <MANAGER_IP> 1515
```

---

## Wazuh Manager Setup (Manager VM)

### Start/Stop/Status

**Start services:**

```bash
sudo systemctl start wazuh-indexer
sudo systemctl start wazuh-manager
sudo systemctl start wazuh-dashboard
```

**Enable autostart on boot:**

```bash
sudo systemctl enable wazuh-indexer wazuh-manager wazuh-dashboard
```

**Verify status:**

```bash
sudo systemctl status wazuh-indexer --no-pager
sudo systemctl status wazuh-manager --no-pager
sudo systemctl status wazuh-dashboard --no-pager
```

**Confirm listening ports:**

```bash
sudo ss -lntup | egrep '1514|1515|443|5601|9200'
```

### Access Dashboard (from within the lab)

Because the lab is operated inside the VMs, open a browser **on the Manager VM** and use:

- `https://<MANAGER_VM_IP>/` (common)
- `https://<MANAGER_VM_IP>:5601/` (some deployments)

**Screenshot:** Wazuh Overview page

![Dashboard Overview](./screenshots/topic-1/dashboard.png)

---

## Wazuh Agent Deployment (Agent VM)

### Install/Enroll Agent

> **Note:** Enrollment methods vary by Wazuh version (UI-generated commands vs CLI).  
> The key requirement is:
> - enrollment over **1515**
> - event forwarding over **1514**
> - using the **correct, reachable manager IP**

**Common CLI-based enrollment flow:**

```bash
sudo systemctl stop wazuh-agent
sudo rm -f /var/ossec/etc/client.keys

sudo /var/ossec/bin/agent-auth -m <MANAGER_IP> -p 1515 -A "ubuntu-agent-01"

sudo systemctl start wazuh-agent
```

**Verify agent service:**

```bash
sudo systemctl status wazuh-agent --no-pager
```

**Verify agent connectivity via logs:**

```bash
sudo tail -n 120 /var/ossec/logs/ossec.log
```

**Screenshot:** successful enrollment + syscheck activity

![Agent Enrollment Terminal](./screenshots/topic-1/agent_deployed.png)

---

## Troubleshooting & Debugging Notes

### Issue: Agent running but NOT visible in Dashboard

**Symptoms:**

- Agent service shows `active (running)`
- Agent does not appear (or remains disconnected) in Wazuh Dashboard

**Common root cause:**

- Agent attempts to enroll/connect to the **wrong manager IP** (frequently a NAT IP).
- **Fix:** point the agent to the **reachable Host-only/Bridged manager IP**.

**High-signal checks (Agent VM):**

```bash
# Confirm reachability to manager ports
nc -vz <MANAGER_IP> 1514
nc -vz <MANAGER_IP> 1515

# Inspect agent logs for enrollment/connect errors
sudo tail -n 200 /var/ossec/logs/ossec.log
```

**High-signal checks (Manager VM):**

```bash
# Confirm manager is listening on required ports
sudo ss -lntup | egrep '1514|1515'

# Confirm agent registration exists
sudo /var/ossec/bin/manage_agents -l

# Inspect manager logs for authd/remoted/key events
sudo tail -n 200 /var/ossec/logs/ossec.log
```

### Issue: Invalid agent name (enrollment rejected)

**Example symptom:**

- Enrollment fails with "Invalid agent name" when using a conflicting hostname or reserved identity

**Fix:**

Re-enroll with a unique agent name (e.g., `ubuntu-agent-01`) and remove old keys before retrying:

```bash
sudo systemctl stop wazuh-agent
sudo rm -f /var/ossec/etc/client.keys
sudo /var/ossec/bin/agent-auth -m <MANAGER_IP> -p 1515 -A "ubuntu-agent-01"
sudo systemctl start wazuh-agent
```

---

## Validation & Output Evidence

### 1) Agent appears as Active in Dashboard

![Agent Visible in Wazuh](./screenshots/topic-1/agent_visible.png)

### 2) Events visible in Threat Hunting

![Threat Hunting Events](./screenshots/topic-1/events.png)

### 3) Command evidence (Agent VM)

```bash
sudo tail -n 80 /var/ossec/logs/ossec.log
```

**Expected indicators:**

- syscheck/rootcheck/logcollector activity
- stable connection messages to the manager
- absence of repeated enrollment/connect errors

---

## Conclusion & Key Takeaways

- Deployed **Wazuh Manager (Indexer + Manager + Dashboard)** on an Ubuntu VM and validated dashboard access.
- Enrolled an **Ubuntu Wazuh agent** on a second VM and confirmed event ingestion in **Threat Hunting**.
- Practiced real SOC setup troubleshooting patterns:
  - corrected **wrong manager IP** usage (NAT vs reachable network)
  - resolved **agent identity/name conflicts**
  - validated connectivity via ports **1514/1515** and confirmed via logs + dashboard evidence
- Produced evidence artifacts (dashboard + agent enrollment + event view) suitable for GitHub documentation.

---

## License

This project is open source and available for educational purposes.

## Contributing

Feel free to open issues or submit pull requests with improvements or suggestions.
